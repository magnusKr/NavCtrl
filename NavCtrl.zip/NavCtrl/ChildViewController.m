//
//  ChildViewController.m
//  NavCtrl
//
//  Created by Aditya Narayan on 10/22/13.
//  Copyright (c) 2013 Aditya Narayan. All rights reserved.
//

#import "ChildViewController.h"


@interface ChildViewController ()

@end

@implementation ChildViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
     self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    self.navigationItem.rightBarButtonItem = self.editButtonItem;

    
    if ([self.title isEqualToString:@"Apple mobile devices"]) {
        self.products = [[NSMutableArray alloc ]
                         initWithObjects:@"iPad", @"iPod Touch",@"iPhone", nil];
        self.productImages = [[NSArray alloc ]
                              initWithObjects:@"iPad.png", @"ipodtouch.png",@"iphone.png", nil];
        self.productURL = [[NSArray alloc ]
                           initWithObjects:@"https://www.apple.com/shop/buy-ipad/ipad-air-2", @"https://www.apple.com/shop/buy-iphone/iphone6",@"https://www.apple.com/shop/buy-iphone/iphone5s", nil];
    }
    
    
    else if ([self.title isEqualToString:@"Samsung mobile devices"]) {
        self.products = [[NSMutableArray alloc ]
                         initWithObjects:@"Galaxy S4", @"Galaxy Note", @"Galaxy Tab", nil];
        self.productImages = [[NSArray alloc ]
                              initWithObjects:@"galaxys4.png", @"galaxys5.png",@"galaxys6.png", nil];
        self.productURL = [[NSArray alloc ]
                           initWithObjects:@"http://www.samsung.com/global/microsite/galaxys4/", @"http://www.samsung.com/us/mobile/cell-phones/SM-G925TZDATMB",@"http://www.samsung.com/us/mobile/cell-phones/SM-G925RZKAUSC", nil];
    }
    
    else if ([self.title isEqualToString:@"Motorola mobile devices"]) {
        self.products = [[NSMutableArray alloc ]
                         initWithObjects:@"X Pure Edition", @"Moto E", @"Moto X", nil];
        self.productImages = [[NSArray alloc ]
                              initWithObjects:@"motorola1.png", @"motorola2.png",@"motorola3.jpeg", nil];
        self.productURL = [[NSArray alloc ]
                           initWithObjects:@"https://www.motorola.com/us/products/moto-g", @"http://www.motorola.com/us/products/moto-x-pure-edition",@"https://www.motorola.com/us/smartphones/moto-e-2nd-gen/moto-e-2nd-gen.html", nil];
    }
    
    else if ([self.title isEqualToString:@"HTC mobile devices"]) {
        self.products = [[NSMutableArray alloc ]
                         initWithObjects:@"Desire 123", @"Desire 510", @"Desire 237", nil];
        self.productImages = [[NSArray alloc ]
                              initWithObjects:@"htc1.png", @"htc2.png",@"htc3.png", nil];
        self.productURL = [[NSArray alloc ]
                           initWithObjects:@"http://www.htc.com/us/smartphones/htc-desire-626/", @"http://www.htc.com/us/smartphones/htc-one-mini/",@"http://www.htc.com/us/smartphones/htc-one-max/", nil];
        
    }
    
     [self.tableView reloadData];


}

- (void)viewWillAppear:(BOOL)animated {

    
    [super viewWillAppear:animated];
    
  }

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return [self.products count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    // Configure the cell...
    
    cell.textLabel.text = [self.products objectAtIndex:
                           [indexPath row]];
    
    cell.imageView.image = [UIImage imageNamed:[self.productImages objectAtIndex:[indexPath row]]];
    
    return cell;
}


// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
   
    return YES;
}



// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [self.products removeObjectAtIndex: [indexPath row]];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
   // else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    //}
}


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Table view delegate

// In a xib-based application, navigation from a table can be handled in -tableView:didSelectRowAtIndexPath:
 
 */
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ProductsViewController *detailViewController = [[ProductsViewController alloc] initWithNibName:@"ProductsViewController" bundle:nil];
    detailViewController.someUrlToLoad = [self.productURL objectAtIndex:[indexPath row]];
    detailViewController.title = [self.products objectAtIndex:[indexPath row]];
    
    [self.navigationController pushViewController:detailViewController animated:YES];
    
    [detailViewController release];
    


    

}



@end
